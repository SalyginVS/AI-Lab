import unittest
from vpe import Engine, Query, Probe

def rec(id, key, *, scope="*", version=1, state="active", valid_from=0, valid_to=None, value=None, next_key=None):
    return {
        "id": id, "key": key, "scope": scope, "version": version, "state": state,
        "valid_from": valid_from, "valid_to": valid_to, "value": value, "next_key": next_key,
    }

PARENTS = {"*": None, "team": "*", "alpha": "team", "beta": "team"}

class V2PublicAcceptance(unittest.TestCase):
    def test_snapshot_stays_old_after_commit(self):
        e=Engine([rec("a1","k",scope="alpha",value="old")], PARENTS)
        s=e.snapshot()
        tx=e.begin(); tx.stage([rec("a2","k",scope="alpha",version=2,value="new")])
        self.assertEqual(tx.commit().status, "PUBLISHED")
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "new")
        self.assertEqual(e.lookup(Query("alpha","k",1), snapshot=s)["value"], "old")

    def test_preview_uses_full_candidate(self):
        e=Engine([], PARENTS)
        tx=e.begin()
        tx.stage([rec("a","entry",scope="alpha",next_key="target"), rec("b","target",scope="alpha",value="ok")])
        self.assertEqual(tx.preview(Query("alpha","entry",1))["value"], "ok")
        self.assertEqual(e.lookup(Query("alpha","entry",1))["status"], "MISSING")

    def test_probe_validates_candidate(self):
        e=Engine([rec("a1","k",scope="alpha",value="old")], PARENTS)
        tx=e.begin(); tx.stage([rec("a2","k",scope="alpha",version=2,value="new")])
        out=tx.commit([Probe(Query("alpha","k",1), "new")])
        self.assertEqual(out.status, "PUBLISHED")
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "new")

    def test_failed_probe_has_no_side_effects(self):
        e=Engine([rec("a1","k",scope="alpha",value="old")], PARENTS)
        e.lookup(Query("alpha","k",1))
        before=(e.epoch, e.cache_info(), e.audit_log())
        tx=e.begin(); tx.stage([rec("a2","k",scope="alpha",version=2,value="new")])
        out=tx.commit([Probe(Query("alpha","k",1), "wrong")])
        self.assertEqual(out.status, "VALIDATION_FAILED")
        self.assertEqual((e.epoch, e.cache_info(), e.audit_log()), before)
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "old")

    def test_stale_rejected_even_disjoint(self):
        e=Engine([], PARENTS)
        t1=e.begin(); t2=e.begin()
        t1.stage([rec("a","x",value="1")]); self.assertEqual(t1.commit().status, "PUBLISHED")
        t2.stage([rec("b","y",value="2")])
        self.assertEqual(t2.commit().status, "STALE")
        self.assertEqual(e.lookup(Query("alpha","y",1))["status"], "MISSING")

    def test_first_commit_closes_transaction(self):
        e=Engine([], PARENTS)
        tx=e.begin()
        self.assertEqual(tx.commit().status, "EMPTY")
        self.assertEqual(tx.commit().status, "CLOSED")
        with self.assertRaises(RuntimeError):
            tx.preview(Query("alpha","k",1))

    def test_negative_dependency_invalidates_old_global_answer(self):
        e=Engine([rec("g","k",value="global")], PARENTS)
        q=Query("alpha","k",1)
        self.assertEqual(e.lookup(q)["value"], "global")
        before=e.cache_info()
        self.assertEqual(before.entries, 1)
        tx=e.begin(); tx.stage([rec("l","k",scope="alpha",value="local")]); tx.commit()
        self.assertEqual(e.lookup(q)["value"], "local")

    def test_unrelated_cache_entry_reused(self):
        e=Engine([rec("a","x",value="x"), rec("b","y",value="y")], PARENTS)
        qx=Query("alpha","x",1); qy=Query("alpha","y",1)
        e.lookup(qx); e.lookup(qy)
        info1=e.cache_info()
        tx=e.begin(); tx.stage([rec("a2","x",version=2,value="x2")]); tx.commit()
        info2=e.cache_info()
        self.assertEqual(info2.entries, 1)
        e.lookup(qy)
        info3=e.cache_info()
        self.assertEqual(info3.hits, info2.hits + 1)

    def test_snapshot_read_does_not_touch_live_cache_counters(self):
        e=Engine([rec("a","k",value="x")], PARENTS)
        s=e.snapshot()
        before=e.cache_info()
        e.lookup(Query("alpha","k",1), snapshot=s)
        self.assertEqual(e.cache_info(), before)

    def test_audit_only_successful_commit(self):
        e=Engine([], PARENTS)
        tx=e.begin(); tx.stage([rec("a","k",value="x")]); out=tx.commit()
        self.assertEqual(out.status, "PUBLISHED")
        self.assertEqual(len(e.audit_log()), 1)
        tx2=e.begin(); tx2.stage([rec("b","k",version=2,value="y")])
        self.assertEqual(tx2.commit([Probe(Query("alpha","k",1),"no")]).status, "VALIDATION_FAILED")
        self.assertEqual(len(e.audit_log()), 1)

    def test_lookup_many_is_single_state(self):
        e=Engine([rec("a1","k",value="old")], PARENTS)
        fired={"v":False}
        def hook(i):
            if i == 0 and not fired["v"]:
                fired["v"]=True
                tx=e.begin(); tx.stage([rec("a2","k",version=2,value="new")]); tx.commit()
        e._set_batch_hook(hook)
        out=e.lookup_many([Query("alpha","k",1), Query("alpha","k",1)])
        e._set_batch_hook(None)
        self.assertEqual([r["value"] for r in out], ["old","old"])
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "new")

    def test_stage_invalid_batch_is_all_or_nothing(self):
        e=Engine([], PARENTS)
        tx=e.begin()
        tx.stage([rec("a","k",value="x")])
        with self.assertRaises(ValueError):
            tx.stage([rec("b","z",value="ok"), rec("a","dup",value="bad")])
        self.assertEqual(tx.preview(Query("alpha","k",1))["value"], "x")
        self.assertEqual(tx.preview(Query("alpha","z",1))["status"], "MISSING")

if __name__ == "__main__":
    unittest.main()
