# VPE-Next execution task

Complete the Versioned Policy Engine transition to contract v2.

Normative source: `spec/00_contract_index.md` and the active spec files it lists. Existing code is the starting implementation. Public/regression tests cover only part of the contract.

Allowed production changes:
- `src/vpe/snapshot.py`
- `src/vpe/planner.py`
- `src/vpe/cache.py`
- `src/vpe/transaction.py`
- `src/vpe/engine.py`
- `src/vpe/audit.py`

You may add your own tests only under `tests/local/`. Temporary artifacts only under `.scratch/` and must not remain in the final submission.

Protected: `src/vpe/_core/**`, `src/vpe/__init__.py`, `spec/**`, `tests/regression/**`, `tests/public/**`, `.pi/settings.json`, metadata and this task file. Do not commit/reset/clean Git history.

Work only in this workspace. Do not inspect sibling model workspaces, hidden evaluators, Downloads, external configs, web, or subagents.

Required workflow:
1. Inspect specification, API and current implementation.
2. Implement the v2 contract within allowed files.
3. Run regression/public tests and any local tests you create.
4. Perform one integrated mandatory self-review against all R01–R18.
5. Fix material defects found and rerun affected checks.
6. Finish with: changed files; checks/results; self-review defects/fixes; residual uncertainty.

Do not claim hidden-test results.
