#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT/template"

export PYTHONPATH=src

echo "=== REGRESSION BASELINE ==="
python3 -m unittest discover -s tests/regression -v

echo
echo "=== PUBLIC V2 BASELINE (expected to fail) ==="
set +e
python3 -m unittest discover -s tests/public -v > /tmp/vpe-public.out 2>&1
rc=$?
set -e
cat /tmp/vpe-public.out
test "$rc" -ne 0 || { echo "STOP: public acceptance unexpectedly all green"; exit 1; }

grep -q 'Ran 12 tests' /tmp/vpe-public.out
grep -q 'FAILED (failures=5, errors=1)' /tmp/vpe-public.out

echo "BASELINE_REGRESSION=PASS"
echo "BASELINE_PUBLIC_RED=PASS_EXPECTED_5_FAILURES_1_ERROR"
echo "TASK_PACKAGE_SELF_CHECK=PASS"
