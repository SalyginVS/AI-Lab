# Run

Do not run this inside either model workspace.

On `Precision-5560`, keep the frozen submissions at:

- `/home/vladimir/vpe_next_ab/run1/q6`
- `/home/vladimir/vpe_next_ab/run1/q5`

Then run:

```bash
cd /home/vladimir/vpe_next_hidden_evaluator_v1
./run_pair.sh
```

The runner first copies both submissions to
`/home/vladimir/vpe_next_hidden_eval/run1/`, evaluates the copies, and prints a
paired summary. Candidate failures do not stop evaluation of the other model.

Do not edit either frozen submission before running.
