from __future__ import annotations
from copy import deepcopy
from typing import Iterable

from ._core.codec import state_digest
from ._core.types import CommitEvent, Probe, PublishResult
from ._core.validation import normalize_records
from .planner import resolve_with_dependencies

class Transaction:
    def __init__(self, engine, base_epoch: int, base_records: tuple[dict, ...]) -> None:
        self._engine = engine
        self._base_epoch = base_epoch
        self._base_records = base_records
        self._staged: tuple[dict, ...] = ()
        self._closed = False

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("transaction is closed")

    def stage(self, records: Iterable[dict]) -> None:
        self._ensure_open()
        existing = {r["id"] for r in self._base_records} | {r["id"] for r in self._staged}
        new = normalize_records(records, existing_ids=existing)
        if any(r["scope"] not in self._engine._parents for r in new):
            raise ValueError("record references unknown scope")
        self._staged = self._staged + deepcopy(new)

    def _candidate(self) -> tuple[dict, ...]:
        return self._base_records + self._staged

    def preview(self, query):
        self._ensure_open()
        return resolve_with_dependencies(self._candidate(), self._engine._parents, query).result

    def commit(self, probes: Iterable[Probe] = ()) -> PublishResult:
        self._ensure_open()
        self._closed = True

        if not self._staged:
            return PublishResult("EMPTY", self._engine._epoch, ())

        # v1 defect cluster:
        # - no stale check
        # - probes resolve the current live head rather than the private candidate
        # - successful publication uses base+staged even if head moved
        failures = []
        for index, probe in enumerate(probes):
            actual = self._engine.lookup(probe.query)
            if actual["status"] != "OK" or actual["value"] != probe.expected_value:
                failures.append({"index": index, "result": actual})
        if failures:
            return PublishResult("VALIDATION_FAILED", self._engine._epoch, tuple(failures))

        new_records = self._candidate()
        new_epoch = self._engine._epoch + 1
        changed_cells = {(r["key"], r["scope"]) for r in self._staged}

        self._engine._records = new_records
        self._engine._epoch = new_epoch
        self._engine._cache.invalidate(changed_cells)
        event = CommitEvent(
            epoch=new_epoch,
            base_epoch=self._base_epoch,
            added_ids=tuple(sorted(r["id"] for r in self._staged)),
            changed_cells=tuple(sorted(changed_cells)),
            state_digest=state_digest(new_records),
        )
        self._engine._audit.append(event)
        return PublishResult("PUBLISHED", new_epoch, ())
