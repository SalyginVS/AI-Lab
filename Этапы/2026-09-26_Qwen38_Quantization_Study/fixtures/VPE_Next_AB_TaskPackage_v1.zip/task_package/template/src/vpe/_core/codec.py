from __future__ import annotations
import hashlib, json
from typing import Any

def state_digest(records: tuple[dict[str, Any], ...]) -> str:
    canonical = sorted(records, key=lambda r: (r["id"], r["key"], r["scope"], r["version"]))
    payload = json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
