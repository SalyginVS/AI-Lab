#!/usr/bin/env bash
set -u -o pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC_BASE="/home/vladimir/vpe_next_ab/run1"
OUT_BASE="/home/vladimir/vpe_next_hidden_eval/run1"

test "$(hostname -s)" = "Precision-5560" || {
  echo "STOP: run on Precision-5560"
  exit 2
}

for label in q6 q5; do
  test -d "$SRC_BASE/$label" || {
    echo "STOP: missing frozen submission: $SRC_BASE/$label"
    exit 2
  }
done

test ! -e "$OUT_BASE" || {
  echo "STOP: evaluation output already exists: $OUT_BASE"
  exit 2
}

mkdir -p "$OUT_BASE"

printf '\n=== FREEZE COPIES ===\n'
for label in q6 q5; do
  cp -a "$SRC_BASE/$label" "$OUT_BASE/$label"

  (
    cd "$OUT_BASE/$label"
    find . \
      -path './.git' -prune -o \
      -path '*/__pycache__' -prune -o \
      -type f -print0 \
      | sort -z \
      | xargs -0 sha256sum \
      | sha256sum \
      > "$OUT_BASE/${label}.tree.sha256"
  )
  printf '%s ' "$label"
  cat "$OUT_BASE/${label}.tree.sha256"
done

run_eval() {
  label="$1"
  workspace="$OUT_BASE/$label"
  result="$OUT_BASE/${label}.result.json"

  printf '\n=== %s HIDDEN EVALUATION ===\n' "${label^^}"
  PYTHONDONTWRITEBYTECODE=1 \
    python3 "$ROOT/evaluate.py" "$workspace" \
    | tee "$result"
  rc="${PIPESTATUS[0]}"
  printf '%s_EVALUATOR_EXIT=%s\n' "${label^^}" "$rc"
  return 0
}

# Candidate FAIL (exit 1) must not stop the pair.
run_eval q6
run_eval q5

printf '\n=== FINAL A/B ===\n'
python3 - "$OUT_BASE/q6.result.json" "$OUT_BASE/q5.result.json" <<'PY'
import json
import sys
from pathlib import Path

q6 = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
q5 = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))

if "evaluator_error" in q6 or "evaluator_error" in q5:
    print("PAIR_STATUS=EVALUATOR_ERROR")
    print("Q6_ERROR=", q6.get("evaluator_error"))
    print("Q5_ERROR=", q5.get("evaluator_error"))
    raise SystemExit(2)

for label, r in (("Q6", q6), ("Q5", q5)):
    print(
        f"{label}: "
        f"scope_ok={r['scope_ok']} "
        f"regression={r['regression_pass']} "
        f"public={r['public_pass']} "
        f"hidden={r['hidden_pass']}/{r['hidden_total']} "
        f"overall={r['overall_pass']}"
    )

q6_fail = {x["name"] for x in q6["hidden_failures"]}
q5_fail = {x["name"] for x in q5["hidden_failures"]}

print(f"HIDDEN_DELTA_Q6_MINUS_Q5={q6['hidden_pass'] - q5['hidden_pass']:+d}")
print(f"Q6_ONLY_CORRECT={len(q5_fail - q6_fail)}")
print(f"Q5_ONLY_CORRECT={len(q6_fail - q5_fail)}")
print(f"BOTH_WRONG={len(q6_fail & q5_fail)}")

if q5_fail - q6_fail:
    print("Q6_ONLY_CORRECT_CASES=" + ",".join(sorted(q5_fail - q6_fail)))
if q6_fail - q5_fail:
    print("Q5_ONLY_CORRECT_CASES=" + ",".join(sorted(q6_fail - q5_fail)))
if q6_fail & q5_fail:
    print("BOTH_WRONG_CASES=" + ",".join(sorted(q6_fail & q5_fail)))

print("Q6_DIGEST_ADVISORY=" + json.dumps(q6.get("digest_advisory", {}), ensure_ascii=False))
print("Q5_DIGEST_ADVISORY=" + json.dumps(q5.get("digest_advisory", {}), ensure_ascii=False))
print(f"RESULT_DIR={Path(sys.argv[1]).parent}")
PY
