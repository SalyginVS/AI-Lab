# Audit and public API

Public imports from `vpe` stay compatible:
`Engine, Query, Probe, PublishResult, CommitEvent, CacheInfo`.

Result dict has exactly:
`status`, `value`, `evidence`.
Statuses: `OK`, `MISSING`, `REVOKED`, `AMBIGUOUS`, `CYCLE`.
Only `OK` may have a string value; all other values are `None`.

`PublishResult.status`: `PUBLISHED`, `VALIDATION_FAILED`, `STALE`, `EMPTY`, `CLOSED`.
`PublishResult.epoch` is the current head epoch after the attempt.

Audit contains only successful publications. One successful commit appends exactly one deterministic `CommitEvent`:
- `epoch`: new epoch
- `base_epoch`: transaction base epoch
- `added_ids`: staged ids, sorted
- `changed_cells`: unique `(key, scope)` cells, sorted
- `state_digest`: digest of newly published records via frozen `_core.codec.state_digest`

No event is appended for VALIDATION_FAILED/STALE/EMPTY/CLOSED.
