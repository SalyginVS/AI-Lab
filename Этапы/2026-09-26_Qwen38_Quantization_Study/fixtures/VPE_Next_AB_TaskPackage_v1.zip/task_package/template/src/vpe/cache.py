from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from ._core.types import CacheInfo, Cell

@dataclass
class _Entry:
    result: dict
    dependencies: frozenset[Cell]
    epoch: int

class LiveCache:
    def __init__(self) -> None:
        self._items: dict[tuple[str, str, int], _Entry] = {}
        self._hits = 0
        self._misses = 0

    def get(self, key: tuple[str, str, int], epoch: int) -> dict | None:
        item = self._items.get(key)
        if item is None or item.epoch != epoch:
            self._misses += 1
            return None
        self._hits += 1
        return deepcopy(item.result)

    def put(self, key: tuple[str, str, int], result: dict, dependencies: frozenset[Cell], epoch: int) -> None:
        self._items[key] = _Entry(deepcopy(result), dependencies, epoch)

    def invalidate(self, changed_cells: set[Cell]) -> None:
        # v1 over-invalidates: every publication clears the whole cache.
        self._items.clear()

    def info(self) -> CacheInfo:
        return CacheInfo(len(self._items), self._hits, self._misses)

    def snapshot_state(self):
        return deepcopy((self._items, self._hits, self._misses))
