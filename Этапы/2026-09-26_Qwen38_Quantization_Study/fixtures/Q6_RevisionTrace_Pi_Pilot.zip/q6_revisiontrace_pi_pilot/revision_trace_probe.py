#!/usr/bin/env python3
"""Original, offline RevisionTrace probe. Python 3.10+, standard library only.

This is a task generator and exact grader, not an inference runner.
Never expose the generator, reference solver, or answer key to a tested agent.
The example distributed with this package is public development data, not holdout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from pathlib import Path
from typing import Any

VERSION = "1.0"
STATUSES = {"RESOLVED", "REVOKED", "MISSING", "CYCLE"}
RULES = """# RevisionTrace: восстановление актуальных ссылок

Это синтетическая задача. Используй только правила и записи ниже.
Не используй инструменты, код, внешние знания или предыдущие ответы.
Найди результат каждого запроса, переходя по цепочке ссылок.

Каждая запись содержит id, alias, project, revision, state, start, end и target.
У запроса есть id, alias, project и at. Время и версии являются целыми числами.

Правила:
1. Начни с alias запроса. На каждом переходе проект и время запроса неизменны.
2. Рассматривай только записи с точным совпадением alias, state=ACTIVE,
   start <= at < end и project, равным проекту запроса или '*'.
3. Сначала выбери наиболее конкретную область: точный project важнее '*'.
   Только внутри выбранной области возьми максимальную revision.
   При равной revision побеждает лексикографически наибольший id.
   Порядок записей в документе не влияет на результат.
4. Нет подходящей записи: статус MISSING, value=null.
5. target=null у выбранной записи означает REVOKED, value=null.
   Нельзя возвращаться к старой версии или к глобальной записи.
6. target, начинающийся с 'result:', является конечным значением.
   Верни статус RESOLVED и этот target целиком как value.
7. Иначе target является следующим alias. Продолжай переходы.
8. Повторное посещение alias означает CYCLE, value=null.
9. evidence содержит id выбранных записей в порядке переходов.
   Включи запись отзыва или запись, замкнувшую цикл. Для MISSING
   включи только записи уже сделанных переходов.

Верни только JSON, без Markdown. Формат:
{"answers":[{"id":"<query id>","status":"RESOLVED|REVOKED|MISSING|CYCLE",
"value":"result:... или null","evidence":["<record id>"]}]}
Для каждого запроса нужна ровно одна запись. Порядок answers произвольный.
Других полей не добавляй. evidence является списком ссылок на данные,
а не объяснением хода рассуждений.
"""


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def solve(world: dict[str, Any], mutant: str | None = None) -> dict[str, Any]:
    """Deterministic reference interpreter; mutant is used only in self-tests."""
    out = []
    records = world["records"]
    for q in world["queries"]:
        alias = q["alias"]
        seen: set[str] = set()
        evidence: list[str] = []
        while True:
            if alias in seen:
                status, value = "CYCLE", None
                break
            seen.add(alias)
            candidates = []
            for r in records:
                if r["alias"] != alias:
                    continue
                if mutant != "ignore_draft" and r["state"] != "ACTIVE":
                    continue
                time_ok = r["start"] <= q["at"] < r["end"]
                if mutant == "inclusive_end":
                    time_ok = r["start"] <= q["at"] <= r["end"]
                if mutant != "ignore_time" and not time_ok:
                    continue
                if mutant != "ignore_project" and r["project"] not in ("*", q["project"]):
                    continue
                if mutant == "fallback_after_revoke" and r["target"] is None:
                    continue
                candidates.append(r)
            if not candidates:
                status, value = "MISSING", None
                break
            if mutant == "revision_first":
                key = lambda r: (r["revision"], r["project"] == q["project"], r["id"])
            else:
                key = lambda r: (r["project"] == q["project"], r["revision"], r["id"])
            chosen = max(candidates, key=key)
            evidence.append(chosen["id"])
            target = chosen["target"]
            if target is None:
                status, value = "REVOKED", None
                break
            if target.startswith("result:"):
                status, value = "RESOLVED", target
                break
            alias = target
        out.append({"id": q["id"], "status": status, "value": value, "evidence": evidence})
    return {"answers": out}


def generate(seed: int, hops: int, noise: int) -> dict[str, Any]:
    """Six queries per independent world. Hops and noise are separate controls."""
    if not 2 <= hops <= 32 or not 0 <= noise <= 100000:
        raise ValueError("hops must be 2..32 and noise must be 0..100000")
    rng = random.Random(seed)
    records: list[dict[str, Any]] = []
    queries: list[dict[str, Any]] = []
    used: set[str] = set()

    def token(prefix: str) -> str:
        while True:
            value = prefix + f"{rng.getrandbits(48):012x}"
            if value not in used:
                used.add(value)
                return value

    def add(alias: str, project: str, revision: int, state: str,
            start: int, end: int, target: str | None) -> None:
        records.append(dict(id=token("r-"), alias=alias, project=project,
                            revision=revision, state=state, start=start, end=end, target=target))

    outcomes = ["RESOLVED", "RESOLVED", "RESOLVED", "REVOKED", "MISSING", "CYCLE"]
    rng.shuffle(outcomes)
    for outcome in outcomes:
        project = token("p-")
        at = rng.randint(40, 90)
        chain = [token("n-") for _ in range(hops)]
        queries.append(dict(id=token("q-"), alias=chain[0], project=project, at=at))
        for idx, alias in enumerate(chain):
            scope = project if rng.random() < 0.6 else "*"
            rev = rng.randint(3, 20)
            is_last = idx == hops - 1
            if not is_last:
                target: str | None = chain[idx + 1]
            elif outcome == "REVOKED":
                target = None
            elif outcome == "CYCLE":
                target = chain[rng.randrange(hops - 1)]
            else:
                target = token("result:")
            missing = is_last and outcome == "MISSING"
            if not missing:
                add(alias, scope, rev, "ACTIVE", at - 4, at + 5, target)
                add(alias, scope, rev - 1, "ACTIVE", at - 10, at + 10, token("result:"))
                if scope != "*":
                    add(alias, "*", rev + 100, "ACTIVE", 0, 1000, token("result:"))
            # Plausible but inapplicable alternatives, including exact time boundaries.
            add(alias, project, rev + 200, "DRAFT", 0, 1000, token("result:"))
            add(alias, project, rev + 201, "ACTIVE", at + 1, at + 20, token("result:"))
            add(alias, project, rev + 202, "ACTIVE", 0, at, token("result:"))
            add(alias, token("p-"), rev + 203, "ACTIVE", 0, 1000, token("result:"))
            add(alias + "0", project, rev + 300, "ACTIVE", 0, 1000, token("result:"))
    for _ in range(noise):
        add(token("n-"), rng.choice(["*", token("p-")]), rng.randint(1, 999),
            rng.choice(["ACTIVE", "DRAFT"]), 0, 1000, token("result:"))
    rng.shuffle(records)
    rng.shuffle(queries)
    return {"version": VERSION, "seed": seed, "hops": hops, "noise_records": noise,
            "records": records, "queries": queries}


def render(world: dict[str, Any]) -> str:
    # Seed, intended outcomes and control parameters are deliberately not exposed.
    return (RULES + "\n## Записи\n" + "\n".join(canonical(r) for r in world["records"])
            + "\n\n## Запросы\n" + "\n".join(canonical(q) for q in world["queries"]) + "\n")


def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in pairs:
        if k in out:
            raise ValueError(f"duplicate JSON key: {k}")
        out[k] = v
    return out


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicates)


def grade(expected: dict[str, Any], actual: Any) -> dict[str, Any]:
    """Separate schema, decision and evidence scores. Never executes model output."""
    n = len(expected["answers"])
    bad = {"schema_ok": False, "queries": n, "decision_correct": 0,
           "evidence_correct": 0, "full_correct": 0, "case_pass": False}
    if not isinstance(actual, dict) or set(actual) != {"answers"}:
        return bad
    answers = actual["answers"]
    if not isinstance(answers, list) or len(answers) != n:
        return bad
    by_id = {}
    for a in answers:
        if not isinstance(a, dict) or set(a) != {"id", "status", "value", "evidence"}:
            return bad
        if not isinstance(a["id"], str) or a["id"] in by_id:
            return bad
        if not isinstance(a["status"], str) or a["status"] not in STATUSES:
            return bad
        if a["value"] is not None and not isinstance(a["value"], str):
            return bad
        if not isinstance(a["evidence"], list) or not all(isinstance(x, str) for x in a["evidence"]):
            return bad
        by_id[a["id"]] = a
    if set(by_id) != {a["id"] for a in expected["answers"]}:
        return bad
    decision = evidence = full = 0
    for e in expected["answers"]:
        a = by_id[e["id"]]
        d = (a["status"], a["value"]) == (e["status"], e["value"])
        t = a["evidence"] == e["evidence"]
        decision += int(d)
        evidence += int(t)
        full += int(d and t)
    return {"schema_ok": True, "queries": n, "decision_correct": decision,
            "evidence_correct": evidence, "full_correct": full, "case_pass": full == n}


def hand_world() -> tuple[dict[str, Any], dict[str, Any]]:
    def r(i: str, alias: str, project: str, rev: int, state: str,
          start: int, end: int, target: str | None) -> dict[str, Any]:
        return dict(id=i, alias=alias, project=project, revision=rev,
                    state=state, start=start, end=end, target=target)
    records = [
        r("r01", "gate", "*", 9, "ACTIVE", 0, 100, "result:red"),
        r("r02", "gate", "A", 2, "ACTIVE", 0, 100, "hop1"),
        r("r03", "gate", "A", 3, "DRAFT", 0, 100, "result:yellow"),
        r("r04", "hop1", "*", 1, "ACTIVE", 0, 100, "hop2"),
        r("r05", "hop2", "*", 5, "ACTIVE", 0, 100, "result:blue"),
        r("r06", "hop2", "*", 6, "ACTIVE", 0, 50, "result:green"),
        r("r07", "hop2", "*", 7, "ACTIVE", 50, 100, None),
        r("r08", "hop2", "B", 90, "ACTIVE", 0, 100, "result:purple"),
        r("r09", "loop1", "*", 1, "ACTIVE", 0, 100, "loop2"),
        r("r10", "loop2", "*", 1, "ACTIVE", 0, 100, "loop1"),
        r("r11", "expires", "*", 100, "ACTIVE", 0, 50, "result:old"),
        r("r12", "expires", "*", 1, "ACTIVE", 0, 100, "result:current"),
    ]
    queries = [dict(id=i, alias=a, project=p, at=t) for i, a, p, t in [
        ("q1", "gate", "A", 49), ("q2", "gate", "A", 50),
        ("q3", "gate", "C", 50), ("q4", "loop1", "A", 50),
        ("q5", "absent", "A", 50), ("q6", "expires", "A", 50)]]
    # Hand-derived expected values, not generated by the reference solver.
    expected = {"answers": [
        dict(id="q1", status="RESOLVED", value="result:green", evidence=["r02", "r04", "r06"]),
        dict(id="q2", status="REVOKED", value=None, evidence=["r02", "r04", "r07"]),
        dict(id="q3", status="RESOLVED", value="result:red", evidence=["r01"]),
        dict(id="q4", status="CYCLE", value=None, evidence=["r09", "r10"]),
        dict(id="q5", status="MISSING", value=None, evidence=[]),
        dict(id="q6", status="RESOLVED", value="result:current", evidence=["r12"]),
    ]}
    return {"records": records, "queries": queries}, expected


def self_test() -> dict[str, Any]:
    count = 0
    def check(ok: bool, label: str) -> None:
        nonlocal count
        if not ok:
            raise AssertionError(label)
        count += 1
    world, expected = hand_world()
    check(solve(world) == expected, "hand-derived answers")
    check(grade(expected, expected)["case_pass"], "exact grader")
    check(grade(expected, {"answers": list(reversed(expected["answers"]))})["case_pass"], "answer order")
    for malformed in [None, [], {}, {"answers": []}, {"answers": expected["answers"], "extra": 1}]:
        check(not grade(expected, malformed)["schema_ok"], "malformed output")
    mutants = ["ignore_draft", "ignore_time", "inclusive_end", "ignore_project",
               "revision_first", "fallback_after_revoke"]
    for m in mutants:
        check(solve(world, m) != expected, "undetected mutant " + m)
    for seed in range(40):
        w = generate(seed, 2 + seed % 7, 20)
        answer = solve(w)
        check(grade(answer, answer)["case_pass"], "generated grade")
        check(generate(seed, 2 + seed % 7, 20) == w, "determinism")
        check(sorted(a["status"] for a in answer["answers"]) ==
              sorted(["RESOLVED"] * 3 + ["REVOKED", "MISSING", "CYCLE"]), "intended outcomes")
        changed = dict(w, records=list(reversed(w["records"])))
        check(solve(changed) == answer, "record permutation")
        with_noise = generate(seed, 2 + seed % 7, 100)
        a = {x["id"]: x for x in solve(with_noise)["answers"]}
        b = {x["id"]: x for x in answer["answers"]}
        check(a == b, "irrelevant-noise invariance")
    try:
        json.loads('{"a":1,"a":2}', object_pairs_hook=reject_duplicates)
    except ValueError:
        count += 1
    else:
        raise AssertionError("duplicate JSON key accepted")
    return {"status": "PASS", "checks": count, "mutants_detected": len(mutants),
            "models_called": 0, "empirical_quantization_sensitivity": "NOT_TESTED"}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    s = p.add_subparsers(dest="command", required=True)
    s.add_parser("self-test")
    sample = s.add_parser("generate")
    sample.add_argument("--output", type=Path, required=True)
    sample.add_argument("--seed", type=int, required=True)
    sample.add_argument("--hops", type=int, default=6)
    sample.add_argument("--noise-records", type=int, default=200)
    g = s.add_parser("grade")
    g.add_argument("--key", type=Path, required=True)
    g.add_argument("--answer", type=Path, required=True)
    a = p.parse_args()
    try:
        if a.command == "self-test":
            print(json.dumps(self_test(), indent=2))
            return 0
        if a.command == "grade":
            key = read_json(a.key)
            try:
                answer = read_json(a.answer)
            except (ValueError, UnicodeError):
                answer = None
            result = grade(key, answer)
            print(json.dumps(result, indent=2))
            return 0 if result["case_pass"] else 1
        w = generate(a.seed, a.hops, a.noise_records)
        prompt = render(w)
        root = a.output.expanduser().resolve()
        # Refuse to replace an existing experiment or evidence directory.
        root.mkdir(parents=True, exist_ok=False)
        public = root / "model_input"
        private = root / "evaluator_only"
        public.mkdir()
        private.mkdir(mode=0o700)
        (public / "prompt.txt").write_text(prompt, encoding="utf-8")
        (private / "answer.json").write_text(json.dumps(solve(w), indent=2), encoding="utf-8")
        (private / "world.json").write_text(json.dumps(w, indent=2), encoding="utf-8")
        manifest = {"version": VERSION, "seed": a.seed, "hops": a.hops,
                    "noise_records": a.noise_records, "prompt_sha256": digest(prompt),
                    "prompt_utf8_bytes": len(prompt.encode("utf-8")),
                    "prompt_tokens": None,
                    "status": "GENERATED_NOT_TOKEN_CALIBRATED_NOT_MODEL_VALIDATED"}
        (private / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        print(json.dumps({"output": str(root), **manifest}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, AssertionError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
