from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from ._core.selector import select_record
from ._core.types import Cell, Query, result

@dataclass(frozen=True)
class Planned:
    result: dict[str, Any]
    dependencies: frozenset[Cell]

def resolve_with_dependencies(
    records: tuple[dict[str, Any], ...],
    parents: dict[str, str | None],
    query: Query,
) -> Planned:
    # v1 implementation: functionally resolves chains, but dependency tracking
    # only remembers the winning cell. Contract v2 requires all inspected cells.
    evidence: list[str] = []
    deps: set[Cell] = set()
    seen_ids: set[str] = set()
    key = query.key

    while True:
        selected = select_record(records, parents, query.project, key, query.at)
        if selected.status == "MISSING":
            return Planned(result("MISSING", None, evidence), frozenset(deps))
        if selected.status == "AMBIGUOUS":
            return Planned(result("AMBIGUOUS", None, evidence), frozenset(deps))

        rec = selected.record
        assert rec is not None
        deps.add((key, rec["scope"]))

        if rec["id"] in seen_ids:
            evidence.append(rec["id"])
            return Planned(result("CYCLE", None, evidence), frozenset(deps))
        seen_ids.add(rec["id"])
        evidence.append(rec["id"])

        if rec["state"] == "revoked":
            return Planned(result("REVOKED", None, evidence), frozenset(deps))
        if rec["value"] is not None:
            return Planned(result("OK", rec["value"], evidence), frozenset(deps))
        key = rec["next_key"]
