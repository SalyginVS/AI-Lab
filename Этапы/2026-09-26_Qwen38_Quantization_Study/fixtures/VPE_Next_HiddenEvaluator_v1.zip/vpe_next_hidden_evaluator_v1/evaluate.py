#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, importlib, json, os, subprocess, sys, traceback
sys.dont_write_bytecode = True
from pathlib import Path

ALLOWED_PROD={
 'src/vpe/snapshot.py','src/vpe/planner.py','src/vpe/cache.py','src/vpe/transaction.py','src/vpe/engine.py','src/vpe/audit.py'
}
IGNORED_PARTS={'__pycache__','.git'}

class Recorder:
    def __init__(self): self.rows=[]
    def add(self,name,fn):
        try:
            value=fn(); ok = True if value is None else bool(value); detail='' if ok else repr(value)
        except Exception as e:
            ok=False; detail=f'{type(e).__name__}: {e}'
        self.rows.append({'name':name,'pass':ok,'detail':detail})
    @property
    def passed(self): return sum(r['pass'] for r in self.rows)

def rec(id,key,*,scope='*',version=1,state='active',valid_from=0,valid_to=None,value=None,next_key=None):
    return {'id':id,'key':key,'scope':scope,'version':version,'state':state,'valid_from':valid_from,'valid_to':valid_to,'value':value,'next_key':next_key}

P={'*':None,'team':'*','alpha':'team','beta':'team','gamma':'*'}

def eq(a,b):
    if a!=b: raise AssertionError(f'{a!r} != {b!r}')

def raises(exc,fn):
    try: fn()
    except exc: return True
    except Exception as e: raise AssertionError(f'expected {exc.__name__}, got {type(e).__name__}: {e}')
    raise AssertionError(f'expected {exc.__name__}')

def run_suite(ws:Path):
    sys.path.insert(0,str(ws/'src'))
    from vpe import Engine, Query, Probe, PublishResult, CommitEvent, CacheInfo
    from vpe._core.codec import state_digest
    R=Recorder()

    # G01 Selection / hierarchy (12)
    cases=[
      ('G01_local_beats_global', [rec('g','k',version=99,value='g'),rec('l','k',scope='alpha',value='l')], Query('alpha','k',1), {'status':'OK','value':'l','evidence':['l']}),
      ('G01_parent_beats_global',[rec('g','k',version=9,value='g'),rec('t','k',scope='team',value='t')],Query('alpha','k',1),{'status':'OK','value':'t','evidence':['t']}),
      ('G01_local_draft_skipped',[rec('d','k',scope='alpha',version=9,state='draft'),rec('t','k',scope='team',value='t')],Query('alpha','k',1),{'status':'OK','value':'t','evidence':['t']}),
      ('G01_future_local_skipped',[rec('l','k',scope='alpha',valid_from=2,value='l'),rec('g','k',value='g')],Query('alpha','k',1),{'status':'OK','value':'g','evidence':['g']}),
      ('G01_expired_local_skipped',[rec('l','k',scope='alpha',valid_to=1,value='l'),rec('g','k',value='g')],Query('alpha','k',1),{'status':'OK','value':'g','evidence':['g']}),
      ('G01_valid_to_exclusive',[rec('a','k',valid_to=10,value='x')],Query('alpha','k',10),{'status':'MISSING','value':None,'evidence':[]}),
      ('G01_highest_version',[rec('a','k',version=1,value='x'),rec('b','k',version=2,value='y')],Query('alpha','k',1),{'status':'OK','value':'y','evidence':['b']}),
      ('G01_ambiguous_top',[rec('a','k',version=2,value='x'),rec('b','k',version=2,value='y')],Query('alpha','k',1),{'status':'AMBIGUOUS','value':None,'evidence':[]}),
      ('G01_lower_tie_irrelevant',[rec('a','k',version=3,value='z'),rec('b','k',version=2,value='x'),rec('c','k',version=2,value='y')],Query('alpha','k',1),{'status':'OK','value':'z','evidence':['a']}),
      ('G01_revoked_nearest_blocks',[rec('r','k',scope='alpha',state='revoked'),rec('g','k',value='g')],Query('alpha','k',1),{'status':'REVOKED','value':None,'evidence':['r']}),
      ('G01_parent_revoked_blocks_global',[rec('r','k',scope='team',state='revoked'),rec('g','k',value='g')],Query('alpha','k',1),{'status':'REVOKED','value':None,'evidence':['r']}),
      ('G01_unknown_project_error',[rec('g','k',value='g')],Query('unknown','k',1),'RAISE'),
    ]
    for name,records,q,expected in cases:
        def f(records=records,q=q,expected=expected):
            e=Engine(records,P)
            if expected=='RAISE': return raises(ValueError,lambda:e.lookup(q))
            eq(e.lookup(q),expected); return True
        R.add(name,f)

    # G02 chains/evidence (10)
    chaincases=[
      ('G02_two_hop',[rec('a','x',next_key='y'),rec('b','y',value='ok')],Query('alpha','x',1),{'status':'OK','value':'ok','evidence':['a','b']}),
      ('G02_three_hop',[rec('a','x',next_key='y'),rec('b','y',next_key='z'),rec('c','z',value='ok')],Query('alpha','x',1),{'status':'OK','value':'ok','evidence':['a','b','c']}),
      ('G02_late_missing',[rec('a','x',next_key='y')],Query('alpha','x',1),{'status':'MISSING','value':None,'evidence':['a']}),
      ('G02_late_ambiguous',[rec('a','x',next_key='y'),rec('b','y',version=2,value='b'),rec('c','y',version=2,value='c')],Query('alpha','x',1),{'status':'AMBIGUOUS','value':None,'evidence':['a']}),
      ('G02_late_revoked',[rec('a','x',next_key='y'),rec('r','y',state='revoked')],Query('alpha','x',1),{'status':'REVOKED','value':None,'evidence':['a','r']}),
      ('G02_self_cycle',[rec('a','x',next_key='x')],Query('alpha','x',1),{'status':'CYCLE','value':None,'evidence':['a','a']}),
      ('G02_two_cycle',[rec('a','x',next_key='y'),rec('b','y',next_key='x')],Query('alpha','x',1),{'status':'CYCLE','value':None,'evidence':['a','b','a']}),
      ('G02_scope_each_hop',[rec('a','x',scope='alpha',next_key='y'),rec('t','y',scope='team',value='t'),rec('g','y',version=9,value='g')],Query('alpha','x',1),{'status':'OK','value':'t','evidence':['a','t']}),
      ('G02_same_at_each_hop',[rec('a','x',next_key='y'),rec('b','y',valid_from=2,value='future'),rec('c','y',version=0 if False else 1,value='now',valid_to=2)],Query('alpha','x',1),{'status':'OK','value':'now','evidence':['a','c']}),
      ('G02_order_independent',[rec('g','y',value='g'),rec('a','x',next_key='y')],Query('alpha','x',1),{'status':'OK','value':'g','evidence':['a','g']}),
    ]
    for name,records,q,expected in chaincases:
        R.add(name,lambda records=records,q=q,expected=expected: (eq(Engine(records,P).lookup(q),expected),True)[1])

    # G03 snapshots (10)
    def make_oldnew(): return Engine([rec('a1','k',scope='alpha',value='old')],P)
    R.add('G03_snapshot_old_after_commit',lambda: _snap_old(make_oldnew(),Query,rec))
    def _foreign():
        e1=Engine([],P); e2=Engine([],P); s=e1.snapshot(); return raises(ValueError,lambda:e2.lookup(Query('alpha','k',1),snapshot=s))
    R.add('G03_foreign_snapshot_rejected',_foreign)
    def snap_counters():
        e=Engine([rec('a','k',value='x')],P); s=e.snapshot(); before=e.cache_info(); e.lookup(Query('alpha','k',1),snapshot=s); eq(e.cache_info(),before); return True
    R.add('G03_snapshot_no_cache_counters',snap_counters)
    def snap_mutation():
        e=Engine([rec('a','k',scope='alpha',value='x')],P); s=e.snapshot(); r=s.records; r[0]['value']='evil'; eq(e.lookup(Query('alpha','k',1),snapshot=s)['value'],'x'); return True
    R.add('G03_snapshot_records_immutable_view',snap_mutation)
    def source_mutation():
        raw=rec('a','k',scope='alpha',value='x'); e=Engine([raw],P); s=e.snapshot(); raw['value']='evil'; eq(e.lookup(Query('alpha','k',1),snapshot=s)['value'],'x'); return True
    R.add('G03_snapshot_source_mutation_isolated',source_mutation)
    def snapshot_epoch():
        e=Engine([],P); s=e.snapshot(); eq(s.epoch,0); tx=e.begin(); tx.stage([rec('a','k',value='x')]); tx.commit(); eq(s.epoch,0); eq(e.epoch,1); return True
    R.add('G03_snapshot_epoch_pinned',snapshot_epoch)
    def explicit_any_at():
        e=Engine([rec('a','k',valid_from=100,value='future')],P); s=e.snapshot(); eq(e.lookup(Query('alpha','k',100),snapshot=s)['value'],'future'); return True
    R.add('G03_snapshot_at_independent_epoch',explicit_any_at)
    def snapshot_result_copy():
        e=Engine([rec('a','k',value='x')],P); s=e.snapshot(); a=e.lookup(Query('alpha','k',1),snapshot=s); a['evidence'].append('evil'); b=e.lookup(Query('alpha','k',1),snapshot=s); eq(b['evidence'],['a']); return True
    R.add('G03_snapshot_result_copy',snapshot_result_copy)
    def multiple_snaps():
        e=Engine([rec('a','k',value='v1')],P); s0=e.snapshot(); t=e.begin(); t.stage([rec('b','k',version=2,value='v2')]); t.commit(); s1=e.snapshot(); t=e.begin(); t.stage([rec('c','k',version=3,value='v3')]); t.commit(); eq(e.lookup(Query('alpha','k',1),snapshot=s0)['value'],'v1'); eq(e.lookup(Query('alpha','k',1),snapshot=s1)['value'],'v2'); return True
    R.add('G03_multiple_snapshots',multiple_snaps)
    def snap_records_repeat_copy():
        e=Engine([rec('a','k',value='x')],P); s=e.snapshot(); r1=s.records; r2=s.records; r1[0]['value']='z'; eq(r2[0]['value'],'x'); return True
    R.add('G03_snapshot_records_repeat_copy',snap_records_repeat_copy)

    # G04 lookup_many (8)
    def batch_hook():
        e=Engine([rec('a1','k',value='old')],P); fired={'x':False}
        def hook(i):
            if i==0 and not fired['x']:
                fired['x']=True; t=e.begin(); t.stage([rec('a2','k',version=2,value='new')]); eq(t.commit().status,'PUBLISHED')
        e._set_batch_hook(hook); out=e.lookup_many([Query('alpha','k',1),Query('alpha','k',1)]); e._set_batch_hook(None); eq([x['value'] for x in out],['old','old']); eq(e.lookup(Query('alpha','k',1))['value'],'new'); return True
    R.add('G04_batch_pinned_during_hook',batch_hook)
    def explicit_batch():
        e=Engine([rec('a','k',value='old')],P); s=e.snapshot(); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); t.commit(); out=e.lookup_many([Query('alpha','k',1),Query('alpha','k',1)],snapshot=s); eq([x['value'] for x in out],['old','old']); return True
    R.add('G04_explicit_snapshot_batch',explicit_batch)
    def batch_order():
        e=Engine([rec('a','x',value='X'),rec('b','y',value='Y')],P); out=e.lookup_many([Query('alpha','y',1),Query('alpha','x',1)]); eq([x['value'] for x in out],['Y','X']); return True
    R.add('G04_batch_preserves_order',batch_order)
    def batch_empty():
        e=Engine([],P); eq(e.lookup_many([]),[]); return True
    R.add('G04_empty_batch',batch_empty)
    def batch_foreign():
        e1=Engine([],P); e2=Engine([],P); s=e1.snapshot(); return raises(ValueError,lambda:e2.lookup_many([],snapshot=s))
    R.add('G04_batch_foreign_snapshot_rejected',batch_foreign)
    def batch_explicit_no_counters():
        e=Engine([rec('a','k',value='x')],P); s=e.snapshot(); before=e.cache_info(); e.lookup_many([Query('alpha','k',1),Query('alpha','k',1)],snapshot=s); eq(e.cache_info(),before); return True
    R.add('G04_explicit_batch_no_cache_counters',batch_explicit_no_counters)
    def hook_indices():
        e=Engine([rec('a','k',value='x')],P); seen=[]; e._set_batch_hook(lambda i:seen.append(i)); e.lookup_many([Query('alpha','k',1)]*3); e._set_batch_hook(None); eq(seen,[0,1,2]); return True
    R.add('G04_hook_zero_based_indices',hook_indices)
    def batch_results_isolated():
        e=Engine([rec('a','k',value='x')],P); out=e.lookup_many([Query('alpha','k',1),Query('alpha','k',1)]); out[0]['evidence'].append('evil'); eq(out[1]['evidence'],['a']); return True
    R.add('G04_batch_results_independent',batch_results_isolated)

    # G05 staging/preview (10)
    def preview_full():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','entry',scope='alpha',next_key='target'),rec('b','target',scope='alpha',value='ok')]); eq(t.preview(Query('alpha','entry',1))['value'],'ok'); eq(e.lookup(Query('alpha','entry',1))['status'],'MISSING'); return True
    R.add('G05_preview_full_candidate',preview_full)
    def stage_copy():
        raw=rec('a','k',value='x'); e=Engine([],P); t=e.begin(); t.stage([raw]); raw['value']='evil'; eq(t.preview(Query('alpha','k',1))['value'],'x'); return True
    R.add('G05_stage_copies_input',stage_copy)
    def invalid_batch_atomic():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); return raises(ValueError,lambda:t.stage([rec('b','z',value='y'),rec('a','dup',value='bad')])) and t.preview(Query('alpha','z',1))['status']=='MISSING' and t.preview(Query('alpha','k',1))['value']=='x'
    R.add('G05_invalid_stage_all_or_nothing',invalid_batch_atomic)
    def invalid_scope_atomic():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); ok=raises(ValueError,lambda:t.stage([rec('b','z',scope='nope',value='y')])); eq(t.preview(Query('alpha','k',1))['value'],'x'); return ok
    R.add('G05_unknown_scope_stage_atomic',invalid_scope_atomic)
    def stale_preview_private():
        e=Engine([rec('a','k',value='old')],P); t1=e.begin(); t1.stage([rec('b','k',version=2,value='mine')]); t2=e.begin(); t2.stage([rec('c','x',value='other')]); t2.commit(); eq(t1.preview(Query('alpha','k',1))['value'],'mine'); return True
    R.add('G05_stale_preview_uses_base_plus_staged',stale_preview_private)
    def preview_no_counters():
        e=Engine([rec('a','k',value='old')],P); e.lookup(Query('alpha','k',1)); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); before=e.cache_info(); t.preview(Query('alpha','k',1)); eq(e.cache_info(),before); return True
    R.add('G05_preview_no_live_cache_counters',preview_no_counters)
    def preview_no_audit():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); t.preview(Query('alpha','k',1)); eq(e.audit_log(),()); return True
    R.add('G05_preview_no_audit',preview_no_audit)
    def preview_result_copy():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); a=t.preview(Query('alpha','k',1)); a['evidence'].append('evil'); b=t.preview(Query('alpha','k',1)); eq(b['evidence'],['a']); return True
    R.add('G05_preview_result_isolated',preview_result_copy)
    def duplicate_against_staged():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); return raises(ValueError,lambda:t.stage([rec('a','z',value='y')]))
    R.add('G05_duplicate_against_staged_rejected',duplicate_against_staged)
    def head_unmodified_by_stage():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); eq(e.epoch,0); eq(e.lookup(Query('alpha','k',1))['status'],'MISSING'); return True
    R.add('G05_stage_does_not_publish',head_unmodified_by_stage)

    # G06 lifecycle/stale/empty (10)
    def first_empty_closes():
        e=Engine([],P); t=e.begin(); eq(t.commit().status,'EMPTY'); eq(t.commit().status,'CLOSED'); return raises(RuntimeError,lambda:t.preview(Query('alpha','k',1)))
    R.add('G06_empty_closes_transaction',first_empty_closes)
    def failed_closes():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); eq(t.commit([Probe(Query('alpha','k',1),'wrong')]).status,'VALIDATION_FAILED'); eq(t.commit().status,'CLOSED'); return raises(RuntimeError,lambda:t.stage([rec('b','z',value='y')]))
    R.add('G06_validation_failed_closes',failed_closes)
    def published_closes():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); eq(t.commit().status,'PUBLISHED'); eq(t.commit().status,'CLOSED'); return True
    R.add('G06_published_closes',published_closes)
    def stale_closes():
        e=Engine([],P); a=e.begin(); b=e.begin(); a.stage([rec('a','x',value='x')]); a.commit(); b.stage([rec('b','y',value='y')]); eq(b.commit().status,'STALE'); eq(b.commit().status,'CLOSED'); return True
    R.add('G06_stale_closes',stale_closes)
    def stale_before_empty():
        e=Engine([],P); a=e.begin(); b=e.begin(); a.stage([rec('a','x',value='x')]); a.commit(); eq(b.commit().status,'STALE'); return True
    R.add('G06_stale_before_empty',stale_before_empty)
    def stale_disjoint():
        e=Engine([],P); a=e.begin(); b=e.begin(); a.stage([rec('a','x',value='x')]); a.commit(); b.stage([rec('b','y',value='y')]); eq(b.commit().status,'STALE'); eq(e.lookup(Query('alpha','y',1))['status'],'MISSING'); return True
    R.add('G06_stale_disjoint_rejected',stale_disjoint)
    def epoch_increment_one():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='x'),rec('b','y',value='y')]); out=t.commit(); eq(out.epoch,1); eq(e.epoch,1); return True
    R.add('G06_nonempty_batch_epoch_plus_one',epoch_increment_one)
    def empty_epoch_unchanged():
        e=Engine([],P); out=e.begin().commit(); eq(out.epoch,0); eq(e.epoch,0); return True
    R.add('G06_empty_epoch_unchanged',empty_epoch_unchanged)
    def stale_epoch_current():
        e=Engine([],P); a=e.begin(); b=e.begin(); a.stage([rec('a','x',value='x')]); a.commit(); b.stage([rec('b','y',value='y')]); out=b.commit(); eq(out.status,'STALE'); eq(out.epoch,1); return True
    R.add('G06_stale_result_reports_current_epoch',stale_epoch_current)
    def closed_no_probe_eval():
        e=Engine([],P); t=e.begin(); t.commit(); out=t.commit([Probe(Query('unknown','k',1),'x')]); eq(out.status,'CLOSED'); return True
    R.add('G06_closed_no_probe_evaluation',closed_no_probe_eval)

    # G07 probes / atomicity (10)
    def candidate_probe():
        e=Engine([rec('a','k',value='old')],P); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); eq(t.commit([Probe(Query('alpha','k',1),'new')]).status,'PUBLISHED'); return True
    R.add('G07_probe_full_candidate',candidate_probe)
    def probe_chain_staged():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','entry',next_key='target'),rec('b','target',value='ok')]); eq(t.commit([Probe(Query('alpha','entry',1),'ok')]).status,'PUBLISHED'); return True
    R.add('G07_probe_sees_whole_staged_batch',probe_chain_staged)
    def all_failed_order():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='x')]); out=t.commit([Probe(Query('alpha','x',1),'bad1'),Probe(Query('alpha','missing',1),'bad2')]); eq(out.status,'VALIDATION_FAILED'); eq([f['index'] for f in out.failures],[0,1]); return True
    R.add('G07_all_probe_failures_in_order',all_failed_order)
    def failed_no_head_change():
        e=Engine([rec('a','k',value='old')],P); before=(e.epoch,e.lookup(Query('alpha','k',1))); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); out=t.commit([Probe(Query('alpha','k',1),'wrong')]); eq(out.status,'VALIDATION_FAILED'); eq(e.epoch,before[0]); eq(e.lookup(Query('alpha','k',1))['value'],'old'); return True
    R.add('G07_failed_probe_no_head_change',failed_no_head_change)
    def failed_no_cache_change():
        e=Engine([rec('a','k',value='old')],P); q=Query('alpha','k',1); e.lookup(q); before=e.cache_info(); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); t.commit([Probe(q,'wrong')]); eq(e.cache_info(),before); out=e.lookup(q); eq(out['value'],'old'); after=e.cache_info(); eq(after.hits,before.hits+1); return True
    R.add('G07_failed_probe_no_cache_change',failed_no_cache_change)
    def failed_no_audit():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); t.commit([Probe(Query('alpha','k',1),'bad')]); eq(e.audit_log(),()); return True
    R.add('G07_failed_probe_no_audit',failed_no_audit)
    def probes_do_not_use_live_cache():
        e=Engine([rec('a','k',value='old')],P); e.lookup(Query('alpha','k',1)); before=e.cache_info(); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); t.commit([Probe(Query('alpha','k',1),'new')]); # publication may invalidate entries but counters stay
        after=e.cache_info(); eq((after.hits,after.misses),(before.hits,before.misses)); return True
    R.add('G07_probes_do_not_touch_cache_counters',probes_do_not_use_live_cache)
    def rejection_keeps_snapshot():
        e=Engine([rec('a','k',value='old')],P); s=e.snapshot(); t=e.begin(); t.stage([rec('b','k',version=2,value='new')]); t.commit([Probe(Query('alpha','k',1),'bad')]); eq(e.lookup(Query('alpha','k',1),snapshot=s)['value'],'old'); return True
    R.add('G07_rejection_keeps_old_snapshot',rejection_keeps_snapshot)
    def success_all_visible():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='X'),rec('b','y',value='Y')]); t.commit(); eq(e.lookup(Query('alpha','x',1))['value'],'X'); eq(e.lookup(Query('alpha','y',1))['value'],'Y'); return True
    R.add('G07_success_batch_atomic_visibility',success_all_visible)
    def failure_result_copy():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='X')]); out=t.commit([Probe(Query('alpha','missing',1),'Y')]); d=out.failures[0]['result']; d['evidence'].append('evil'); eq(e.lookup(Query('alpha','missing',1))['evidence'],[]); return True
    R.add('G07_failure_result_mutation_isolated',failure_result_copy)

    # G08 cache semantics/dependencies (16)
    def head_hitmiss():
        e=Engine([rec('a','k',value='x')],P); q=Query('alpha','k',1); i0=e.cache_info(); e.lookup(q); i1=e.cache_info(); e.lookup(q); i2=e.cache_info(); eq(i1.misses,i0.misses+1); eq(i2.hits,i1.hits+1); return True
    R.add('G08_head_miss_then_hit',head_hitmiss)
    def key_project():
        e=Engine([rec('a','k',scope='alpha',value='A'),rec('b','k',scope='beta',value='B')],P); eq(e.lookup(Query('alpha','k',1))['value'],'A'); eq(e.lookup(Query('beta','k',1))['value'],'B'); eq(e.cache_info().entries,2); return True
    R.add('G08_cache_key_includes_project',key_project)
    def key_at():
        e=Engine([rec('a','k',valid_to=2,value='early'),rec('b','k',version=2,valid_from=2,value='late')],P); eq(e.lookup(Query('alpha','k',1))['value'],'early'); eq(e.lookup(Query('alpha','k',2))['value'],'late'); eq(e.cache_info().entries,2); return True
    R.add('G08_cache_key_includes_at',key_at)
    def all_status_cached(status,records,key='k'):
        e=Engine(records,P); q=Query('alpha',key,1); a=e.lookup(q); i=e.cache_info(); b=e.lookup(q); j=e.cache_info(); eq(a['status'],status); eq(b,a); eq(j.hits,i.hits+1); return True
    R.add('G08_cache_missing',lambda:all_status_cached('MISSING',[]))
    R.add('G08_cache_revoked',lambda:all_status_cached('REVOKED',[rec('a','k',state='revoked')]))
    R.add('G08_cache_ambiguous',lambda:all_status_cached('AMBIGUOUS',[rec('a','k',version=2,value='a'),rec('b','k',version=2,value='b')]))
    R.add('G08_cache_cycle',lambda:all_status_cached('CYCLE',[rec('a','k',next_key='k')]))
    def negative_dep_local():
        e=Engine([rec('g','k',value='global')],P); q=Query('alpha','k',1); e.lookup(q); t=e.begin(); t.stage([rec('l','k',scope='alpha',value='local')]); t.commit(); before=e.cache_info(); eq(before.entries,0); eq(e.lookup(q)['value'],'local'); return True
    R.add('G08_negative_dependency_local_invalidation',negative_dep_local)
    def negative_dep_parent():
        e=Engine([rec('g','k',value='global')],P); q=Query('alpha','k',1); e.lookup(q); t=e.begin(); t.stage([rec('p','k',scope='team',value='team')]); t.commit(); eq(e.cache_info().entries,0); eq(e.lookup(q)['value'],'team'); return True
    R.add('G08_negative_dependency_parent_invalidation',negative_dep_parent)
    def chain_dep():
        e=Engine([rec('a','entry',scope='alpha',next_key='target'),rec('g','target',value='g')],P); q=Query('alpha','entry',1); e.lookup(q); t=e.begin(); t.stage([rec('l','target',scope='alpha',value='l')]); t.commit(); eq(e.lookup(q)['value'],'l'); return True
    R.add('G08_chain_dependency_invalidation',chain_dep)
    def missing_dep():
        e=Engine([],P); q=Query('alpha','k',1); eq(e.lookup(q)['status'],'MISSING'); t=e.begin(); t.stage([rec('g','k',value='x')]); t.commit(); eq(e.lookup(q)['value'],'x'); return True
    R.add('G08_missing_dependency_invalidated',missing_dep)
    def unrelated_reuse():
        e=Engine([rec('a','x',value='X'),rec('b','y',value='Y')],P); qx=Query('alpha','x',1); qy=Query('alpha','y',1); e.lookup(qx); e.lookup(qy); before=e.cache_info(); t=e.begin(); t.stage([rec('a2','x',version=2,value='X2')]); t.commit(); mid=e.cache_info(); eq(mid.entries,1); e.lookup(qy); after=e.cache_info(); eq(after.hits,mid.hits+1); return True
    R.add('G08_unrelated_entry_reused_across_epoch',unrelated_reuse)
    def draft_change_conservative():
        e=Engine([rec('g','k',value='g')],P); q=Query('alpha','k',1); e.lookup(q); t=e.begin(); t.stage([rec('d','k',scope='alpha',state='draft')]); t.commit(); eq(e.cache_info().entries,0); return True
    R.add('G08_draft_changed_cell_invalidates_conservatively',draft_change_conservative)
    def future_change_conservative():
        e=Engine([rec('g','k',value='g')],P); q=Query('alpha','k',1); e.lookup(q); t=e.begin(); t.stage([rec('f','k',scope='alpha',valid_from=100,value='future')]); t.commit(); eq(e.cache_info().entries,0); return True
    R.add('G08_future_changed_cell_invalidates_conservatively',future_change_conservative)
    def cache_result_copy():
        e=Engine([rec('a','k',value='x')],P); q=Query('alpha','k',1); a=e.lookup(q); a['evidence'].append('evil'); b=e.lookup(q); eq(b['evidence'],['a']); return True
    R.add('G08_cache_result_copy',cache_result_copy)
    def no_epoch_key_flush():
        e=Engine([rec('a','x',value='X'),rec('b','y',value='Y')],P); q=Query('alpha','y',1); e.lookup(q); t=e.begin(); t.stage([rec('a2','x',version=2,value='X2')]); t.commit(); before=e.cache_info(); e.lookup(q); after=e.cache_info(); eq(after.hits,before.hits+1); return True
    R.add('G08_cache_survives_epoch_for_unrelated',no_epoch_key_flush)

    # G09 failed/stale/empty commit exact cache/audit state (6)
    def exact_no_effect(kind):
        e=Engine([rec('a','k',value='x')],P); q=Query('alpha','k',1); eq(e.lookup(q)['value'],'x'); before=(e.epoch,e.cache_info(),e.audit_log())
        if kind=='empty': out=e.begin().commit(); eq(out.status,'EMPTY')
        elif kind=='failed':
            t=e.begin(); t.stage([rec('b','k',version=2,value='y')]); out=t.commit([Probe(q,'bad')]); eq(out.status,'VALIDATION_FAILED')
        elif kind=='stale':
            t=e.begin(); other=e.begin(); other.stage([rec('c','z',value='z')]); other.commit(); t.stage([rec('d','q',value='q')]); before=(e.epoch,e.cache_info(),e.audit_log()); out=t.commit(); eq(out.status,'STALE')
        after=(e.epoch,e.cache_info(),e.audit_log()); eq(after,before); eq(e.lookup(q)['value'],'x'); return True
    R.add('G09_empty_exact_no_effect',lambda:exact_no_effect('empty'))
    R.add('G09_failed_exact_no_effect',lambda:exact_no_effect('failed'))
    R.add('G09_stale_exact_no_effect',lambda:exact_no_effect('stale'))
    def close_after_fail_noeffect():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','k',value='x')]); t.commit([Probe(Query('alpha','k',1),'bad')]); before=(e.epoch,e.cache_info(),e.audit_log()); out=t.commit(); eq(out.status,'CLOSED'); eq((e.epoch,e.cache_info(),e.audit_log()),before); return True
    R.add('G09_closed_exact_no_effect',close_after_fail_noeffect)
    def stage_invalid_open():
        e=Engine([],P); t=e.begin(); raises(ValueError,lambda:t.stage([rec('a','k',scope='nope',value='x')])); t.stage([rec('b','k',value='ok')]); eq(t.preview(Query('alpha','k',1))['value'],'ok'); return True
    R.add('G09_validation_error_leaves_transaction_open',stage_invalid_open)
    def previous_staged_preserved():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='X')]); raises(ValueError,lambda:t.stage([rec('b','y',value='Y'),rec('a','z',value='Z')])); eq(t.preview(Query('alpha','x',1))['value'],'X'); eq(t.preview(Query('alpha','y',1))['status'],'MISSING'); return True
    R.add('G09_validation_error_preserves_previous_stage',previous_staged_preserved)

    # G10 audit / API (8 counted, digest advisory separately)
    def audit_success():
        e=Engine([],P); t=e.begin(); t.stage([rec('b','y',scope='team',value='Y'),rec('a','x',scope='alpha',value='X')]); out=t.commit(); log=e.audit_log(); eq(len(log),1); ev=log[0]; eq(ev.epoch,1); eq(ev.base_epoch,0); eq(ev.added_ids,('a','b')); eq(ev.changed_cells,(('x','alpha'),('y','team'))); return True
    R.add('G10_audit_success_fields_sorted',audit_success)
    def no_audit_failures():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='X')]); t.commit([Probe(Query('alpha','x',1),'bad')]); eq(e.audit_log(),()); return True
    R.add('G10_no_audit_validation_failed',no_audit_failures)
    def no_audit_empty():
        e=Engine([],P); e.begin().commit(); eq(e.audit_log(),()); return True
    R.add('G10_no_audit_empty',no_audit_empty)
    def no_audit_stale():
        e=Engine([],P); a=e.begin(); b=e.begin(); a.stage([rec('a','x',value='X')]); a.commit(); b.stage([rec('b','y',value='Y')]); b.commit(); eq(len(e.audit_log()),1); return True
    R.add('G10_no_audit_stale',no_audit_stale)
    def audit_view_immutable_tuple():
        e=Engine([],P); t=e.begin(); t.stage([rec('a','x',value='X')]); t.commit(); log=e.audit_log(); return raises(AttributeError,lambda:log.append('x'))
    R.add('G10_audit_log_tuple',audit_view_immutable_tuple)
    def exports():
        import vpe; names={'Engine','Query','Probe','PublishResult','CommitEvent','CacheInfo'}; return all(hasattr(vpe,n) for n in names)
    R.add('G10_public_exports_preserved',exports)
    def result_shape():
        e=Engine([rec('a','k',value='x')],P); out=e.lookup(Query('alpha','k',1)); eq(set(out),{'status','value','evidence'}); return True
    R.add('G10_result_shape_exact',result_shape)
    def statuses_value_none():
        for records in ([],[rec('r','k',state='revoked')],[rec('a','k',version=2,value='x'),rec('b','k',version=2,value='y')],[rec('c','k',next_key='k')]):
            out=Engine(records,P).lookup(Query('alpha','k',1));
            if out['status']!='OK': eq(out['value'],None)
        return True
    R.add('G10_non_ok_values_none',statuses_value_none)

    # Exactly 100? Check later. Add deterministic state-digest advisory not counted.
    hidden_total=len(R.rows)
    # Public/regression
    env={**os.environ,'PYTHONPATH':str(ws/'src'),'PYTHONDONTWRITEBYTECODE':'1'}
    reg=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests/regression','-v'],cwd=ws,env=env,text=True,capture_output=True)
    pub=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests/public','-v'],cwd=ws,env=env,text=True,capture_output=True)

    # scope via baseline manifest
    manifest=json.loads((Path(__file__).parent/'BASELINE_MANIFEST.json').read_text())
    protected_fail=[]
    for rel,digest in manifest.items():
        if rel in ALLOWED_PROD or '__pycache__' in rel: continue
        p=ws/rel
        if not p.is_file(): protected_fail.append(f'missing:{rel}'); continue
        got=hashlib.sha256(p.read_bytes()).hexdigest()
        if got!=digest: protected_fail.append(f'modified:{rel}')
    extra=[]
    for p in ws.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ws).as_posix()
        if any(part in IGNORED_PARTS for part in p.relative_to(ws).parts): continue
        if rel in manifest or rel in ALLOWED_PROD or rel.startswith('tests/local/'): continue
        extra.append(rel)
    scope_ok=not protected_fail and not extra

    # advisory digest interpretation
    digest_advisory={}
    try:
        e=Engine([rec('base','base',value='B')],P); t=e.begin(); staged=[rec('new','k',value='X')]; t.stage(staged); t.commit(); ev=e.audit_log()[0]
        full=state_digest(tuple([rec('base','base',value='B')]+staged)); staged_only=state_digest(tuple(staged))
        digest_advisory={'actual':ev.state_digest,'matches_full_published_state':ev.state_digest==full,'matches_staged_only':ev.state_digest==staged_only}
    except Exception as ex: digest_advisory={'error':repr(ex)}

    # Require 100 hidden checks by construction.
    if hidden_total != 100:
        raise RuntimeError(f'evaluator construction error: hidden_total={hidden_total}, expected 100')

    result={
      'workspace':str(ws), 'scope_ok':scope_ok, 'protected_failures':protected_fail, 'unexpected_files':extra,
      'regression_pass':reg.returncode==0, 'public_pass':pub.returncode==0,
      'hidden_pass':R.passed, 'hidden_total':hidden_total,
      'hidden_failures':[r for r in R.rows if not r['pass']],
      'digest_advisory':digest_advisory,
    }
    result['overall_pass']=scope_ok and result['regression_pass'] and result['public_pass'] and R.passed==hidden_total
    return result

def _snap_old(e,Query,rec):
    s=e.snapshot(); t=e.begin(); t.stage([rec('a2','k',scope='alpha',version=2,value='new')]); t.commit();
    eq(e.lookup(Query('alpha','k',1))['value'],'new'); eq(e.lookup(Query('alpha','k',1),snapshot=s)['value'],'old'); return True

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('workspace'); args=ap.parse_args(); ws=Path(args.workspace).resolve()
    try:
        result=run_suite(ws); print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result['overall_pass'] else 1
    except Exception as e:
        print(json.dumps({'evaluator_error':f'{type(e).__name__}: {e}','traceback':traceback.format_exc()},indent=2)); return 2
if __name__=='__main__': raise SystemExit(main())
