from __future__ import annotations
from ._core.types import CommitEvent

class AuditLog:
    def __init__(self) -> None:
        self._events: list[CommitEvent] = []

    def append(self, event: CommitEvent) -> None:
        self._events.append(event)

    def view(self) -> tuple[CommitEvent, ...]:
        return tuple(self._events)
