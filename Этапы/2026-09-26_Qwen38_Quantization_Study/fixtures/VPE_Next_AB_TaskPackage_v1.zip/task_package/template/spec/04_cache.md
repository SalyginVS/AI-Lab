# Live cache and dependencies

Only reads of the current head use the live cache. The key is exactly `(project, key, at)`.
All five statuses may be cached.

Snapshot reads and transaction preview/probe evaluation bypass live cache completely.

A cached entry stores the Result plus the set of inspected logical cells `(key, scope)` from its resolution.
Dependencies include empty inspected cells. Example: if `alpha` has no local `limit` and the result comes from `*`, dependencies include both `("limit","alpha")` and `("limit","*")`.
For chains, union dependencies from every hop, including the cells inspected before MISSING/AMBIGUOUS/REVOKED.

A successful publication computes `changed_cells = {(key, scope) for each staged record}`.
Invalidate exactly cached entries whose dependency set intersects `changed_cells`. Preserve unrelated entries and their reuse.

Cache info counters:
- current-head miss increments `misses`;
- current-head hit increments `hits`;
- snapshot/preview/probe evaluation changes neither;
- failed/stale/empty commits change neither.

Returned Results are copies. Caller mutation must not corrupt a cached result.
