import unittest
from vpe import Engine, Query

def rec(id, key, *, scope="*", version=1, state="active", valid_from=0, valid_to=None, value=None, next_key=None):
    return {
        "id": id, "key": key, "scope": scope, "version": version, "state": state,
        "valid_from": valid_from, "valid_to": valid_to, "value": value, "next_key": next_key,
    }

PARENTS = {"*": None, "team": "*", "alpha": "team", "beta": "team"}

class SelectionRegression(unittest.TestCase):
    def test_terminal_global(self):
        e=Engine([rec("g","k",value="x")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1)), {"status":"OK","value":"x","evidence":["g"]})

    def test_nearest_scope(self):
        e=Engine([rec("g","k",version=99,value="g"), rec("t","k",scope="team",value="t"), rec("a","k",scope="alpha",value="a")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "a")

    def test_parent_scope(self):
        e=Engine([rec("g","k",version=99,value="g"), rec("t","k",scope="team",value="t")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "t")

    def test_draft_does_not_block_parent(self):
        e=Engine([rec("a","k",scope="alpha",state="draft",value=None), rec("t","k",scope="team",value="t")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1))["value"], "t")

    def test_valid_to_exclusive(self):
        e=Engine([rec("x","k",valid_to=10,value="x")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",10))["status"], "MISSING")

    def test_ambiguous(self):
        e=Engine([rec("a","k",version=2,value="a"), rec("b","k",version=2,value="b")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1)), {"status":"AMBIGUOUS","value":None,"evidence":[]})

    def test_revoked_no_fallback(self):
        e=Engine([rec("old","k",version=1,value="x"), rec("rev","k",version=2,state="revoked")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","k",1)), {"status":"REVOKED","value":None,"evidence":["rev"]})

    def test_chain(self):
        e=Engine([rec("a","a",next_key="b"), rec("b","b",next_key="c"), rec("c","c",value="done")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","a",1)), {"status":"OK","value":"done","evidence":["a","b","c"]})

    def test_cycle_closing_id(self):
        e=Engine([rec("a","a",next_key="b"), rec("b","b",next_key="a")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","a",1)), {"status":"CYCLE","value":None,"evidence":["a","b","a"]})

    def test_late_missing_preserves_evidence(self):
        e=Engine([rec("a","a",next_key="b")], PARENTS)
        self.assertEqual(e.lookup(Query("alpha","a",1)), {"status":"MISSING","value":None,"evidence":["a"]})

    def test_snapshot_basic(self):
        e=Engine([rec("a","k",value="x")], PARENTS)
        s=e.snapshot()
        self.assertEqual(s.epoch, 0)
        self.assertEqual(e.lookup(Query("alpha","k",1), snapshot=s)["value"], "x")

    def test_cache_returns_copy(self):
        e=Engine([rec("a","k",value="x")], PARENTS)
        r=e.lookup(Query("alpha","k",1)); r["evidence"].append("BAD")
        self.assertEqual(e.lookup(Query("alpha","k",1))["evidence"], ["a"])

if __name__ == "__main__":
    unittest.main()
