from __future__ import annotations
from copy import deepcopy
from typing import Any, Iterable

_ALLOWED_STATES = {"active", "draft", "revoked"}

def validate_hierarchy(parents: dict[str, str | None]) -> dict[str, str | None]:
    out = dict(parents)
    if out.get("*", None) is not None:
        raise ValueError("global scope '*' must have no parent")
    if "*" not in out:
        out["*"] = None
    for scope in list(out):
        seen = set()
        cur = scope
        while cur != "*":
            if cur in seen:
                raise ValueError("scope hierarchy cycle")
            seen.add(cur)
            if cur not in out or out[cur] is None:
                raise ValueError(f"unknown or disconnected scope: {cur}")
            cur = out[cur]
        if cur != "*":
            raise ValueError("scope hierarchy must terminate at '*'")
    return out

def scope_path(parents: dict[str, str | None], project: str) -> tuple[str, ...]:
    if project not in parents:
        raise ValueError(f"unknown project/scope: {project}")
    out = []
    cur = project
    while True:
        out.append(cur)
        if cur == "*":
            break
        cur = parents[cur]
        if cur is None:
            raise ValueError(f"disconnected scope: {project}")
    return tuple(out)

def _validate_record(r: dict[str, Any]) -> dict[str, Any]:
    required = {"id","key","scope","version","state","valid_from","valid_to","value","next_key"}
    if set(r) != required:
        raise ValueError("record fields mismatch")
    if not all(isinstance(r[k], str) for k in ("id","key","scope","state")):
        raise ValueError("id/key/scope/state must be strings")
    if not r["id"] or not r["key"] or not r["scope"]:
        raise ValueError("id/key/scope cannot be empty")
    if r["state"] not in _ALLOWED_STATES:
        raise ValueError("invalid state")
    if not isinstance(r["version"], int) or isinstance(r["version"], bool) or r["version"] <= 0:
        raise ValueError("version must be positive int")
    if not isinstance(r["valid_from"], int) or isinstance(r["valid_from"], bool):
        raise ValueError("valid_from must be int")
    if r["valid_to"] is not None:
        if not isinstance(r["valid_to"], int) or isinstance(r["valid_to"], bool):
            raise ValueError("valid_to must be int or None")
        if r["valid_from"] >= r["valid_to"]:
            raise ValueError("valid interval must be non-empty")
    if r["state"] == "active":
        if (r["value"] is None) == (r["next_key"] is None):
            raise ValueError("active record must have exactly one of value/next_key")
        if r["value"] is not None and not isinstance(r["value"], str):
            raise ValueError("value must be str or None")
        if r["next_key"] is not None and (not isinstance(r["next_key"], str) or not r["next_key"]):
            raise ValueError("next_key must be non-empty str or None")
    return deepcopy(r)

def normalize_records(records: Iterable[dict[str, Any]], *, existing_ids: set[str] | None = None) -> tuple[dict[str, Any], ...]:
    seen = set(existing_ids or ())
    out = []
    for raw in records:
        r = _validate_record(raw)
        if r["id"] in seen:
            raise ValueError(f"duplicate record id: {r['id']}")
        seen.add(r["id"])
        out.append(r)
    return tuple(out)
