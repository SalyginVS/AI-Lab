from __future__ import annotations
from copy import deepcopy
from typing import Callable, Iterable

from ._core.types import CacheInfo, Query
from ._core.validation import normalize_records, validate_hierarchy
from .audit import AuditLog
from .cache import LiveCache
from .planner import resolve_with_dependencies
from .snapshot import Snapshot

class Engine:
    def __init__(self, records: Iterable[dict], parents: dict[str, str | None]) -> None:
        self._parents = validate_hierarchy(parents)
        self._records = normalize_records(records)
        known_scopes = set(self._parents)
        if any(r["scope"] not in known_scopes for r in self._records):
            raise ValueError("record references unknown scope")
        self._epoch = 0
        self._engine_token = object()
        self._cache = LiveCache()
        self._audit = AuditLog()
        self._batch_hook: Callable[[int], None] | None = None

    @property
    def epoch(self) -> int:
        return self._epoch

    def snapshot(self) -> Snapshot:
        return Snapshot(self._engine_token, self._epoch, deepcopy(self._records))

    def _validate_snapshot(self, snap: Snapshot) -> None:
        if snap._engine_token is not self._engine_token:
            raise ValueError("snapshot belongs to another engine")

    def lookup(self, query: Query, *, snapshot: Snapshot | None = None) -> dict:
        if snapshot is not None:
            self._validate_snapshot(snapshot)
            return resolve_with_dependencies(snapshot.records, self._parents, query).result

        key = (query.project, query.key, query.at)
        cached = self._cache.get(key, self._epoch)
        if cached is not None:
            return cached
        planned = resolve_with_dependencies(self._records, self._parents, query)
        self._cache.put(key, planned.result, planned.dependencies, self._epoch)
        return deepcopy(planned.result)

    def lookup_many(self, queries: Iterable[Query], *, snapshot: Snapshot | None = None) -> list[dict]:
        # v1 bug: without explicit snapshot, each item reads the live head
        # separately. A publication in the test seam can mix epochs.
        out = []
        for i, query in enumerate(queries):
            out.append(self.lookup(query, snapshot=snapshot))
            if self._batch_hook is not None:
                self._batch_hook(i)
        return out

    def begin(self):
        from .transaction import Transaction
        return Transaction(self, self._epoch, deepcopy(self._records))

    def audit_log(self):
        return self._audit.view()

    def cache_info(self) -> CacheInfo:
        return self._cache.info()

    # Frozen test seam. Production callers do not need it.
    def _set_batch_hook(self, hook: Callable[[int], None] | None) -> None:
        self._batch_hook = hook
