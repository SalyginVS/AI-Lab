#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

Q5='qwen3.8-flash-next:125b-a6b-q5_K_M-ab-262k'
Q6='qwen3.8-flash-next:125b-a6b-q6_K-ab-262k'
PROVIDER='ailab-ollama'

printf '=== PREFLIGHT ===\n'
printf 'host=%s\n' "$(hostname -s)"
printf 'pi_version=%s\n' "$(pi --version)"

test "$(hostname -s)" = 'Precision-5560' || {
  echo 'STOP: run on Precision-5560'
  exit 1
}

command -v pi >/dev/null
command -v python3 >/dev/null

models="$(pi --list-models 2>/dev/null || true)"
printf '%s\n' "$models" | grep -F "$Q5" >/dev/null || {
  echo "STOP: Q5 not found in Pi model catalog"
  exit 1
}
printf '%s\n' "$models" | grep -F "$Q6" >/dev/null || {
  echo "STOP: Q6 not found in Pi model catalog"
  exit 1
}

printf '\n=== REVISIONTRACE SELF-TEST ===\n'
python3 "$ROOT/revision_trace_probe.py" self-test

RUN_DIR="$ROOT/runs/$(date +%Y%m%d_%H%M%S)"
WORLD_DIR="$RUN_DIR/world"
mkdir -p "$RUN_DIR"

printf '\n=== GENERATE PILOT WORLD ===\n'
python3 "$ROOT/revision_trace_probe.py" generate \
  --output "$WORLD_DIR" \
  --seed 2026092501 \
  --hops 8 \
  --noise-records 300

PROMPT="$WORLD_DIR/model_input/prompt.txt"
KEY="$WORLD_DIR/evaluator_only/answer.json"

printf '\n=== PILOT INPUT ===\n'
wc -c "$PROMPT"
sha256sum "$PROMPT"
printf 'RUN_DIR=%s\n' "$RUN_DIR"

run_model() {
  label="$1"
  model="$2"
  answer="$RUN_DIR/${label}.answer.json"
  stderr="$RUN_DIR/${label}.stderr.log"
  grade="$RUN_DIR/${label}.grade.json"

  printf '\n=== RUN %s ===\n' "$label"
  printf 'model=%s\n' "$model"
  start="$(date +%s)"

  PI_SKIP_VERSION_CHECK=1 \
  pi \
    --provider "$PROVIDER" \
    --model "$model" \
    --thinking max \
    --no-tools \
    --no-session \
    --print \
    @"$PROMPT" \
    "Solve the RevisionTrace task from the included file. Return only the JSON required by the task." \
    >"$answer" 2>"$stderr"

  end="$(date +%s)"
  printf '%s\n' "$((end-start))" > "$RUN_DIR/${label}.wall_seconds.txt"

  printf '%s wall_seconds=%s\n' "$label" "$((end-start))"
  printf '%s answer_sha256=' "$label"
  sha256sum "$answer" | awk '{print $1}'

  python3 "$ROOT/revision_trace_probe.py" grade \
    --key "$KEY" \
    --answer "$answer" \
    | tee "$grade"
}

# Screening pilot only. Performance is not scored, so running Q6 first is acceptable.
run_model Q6 "$Q6"
run_model Q5 "$Q5"

printf '\n=== SUMMARY ===\n'
python3 - "$RUN_DIR" <<'PY'
import json, sys
from pathlib import Path
run = Path(sys.argv[1])
for label in ("Q6", "Q5"):
    g = json.loads((run / f"{label}.grade.json").read_text())
    wall = (run / f"{label}.wall_seconds.txt").read_text().strip()
    print(
        f"{label}: case_pass={g['case_pass']} "
        f"full_correct={g['full_correct']}/{g['queries']} "
        f"decision_correct={g['decision_correct']}/{g['queries']} "
        f"evidence_correct={g['evidence_correct']}/{g['queries']} "
        f"wall_seconds={wall}"
    )

q6 = json.loads((run / "Q6.grade.json").read_text())
q5 = json.loads((run / "Q5.grade.json").read_text())

if q6["full_correct"] > q5["full_correct"]:
    verdict = "PILOT_SIGNAL_Q6_POSITIVE"
elif q6["full_correct"] < q5["full_correct"]:
    verdict = "PILOT_SIGNAL_Q5_POSITIVE"
else:
    verdict = "PILOT_TIE"

print(f"PILOT_VERDICT={verdict}")
print(f"RUN_DIR={run}")
PY
