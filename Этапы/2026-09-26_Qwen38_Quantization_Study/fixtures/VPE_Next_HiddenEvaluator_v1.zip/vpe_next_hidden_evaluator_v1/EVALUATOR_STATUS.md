# VPE-Next hidden evaluator v1

Purpose: external post-submission evaluation of the frozen Q6 and Q5 VPE-Next workspaces.

Properties of this materialization:
- 100 hidden semantic checks.
- regression and public suites are rerun.
- protected-file/scope check uses the baseline manifest.
- `__pycache__` / `.pyc` runtime artifacts are ignored for scope.
- `tests/local/**` is allowed.
- `.scratch/**` remaining in the final submission is not allowed.
- evaluation is run on copies, not on the frozen submissions.
- the audit state-digest interpretation is reported as an advisory field and is not part of the 100-score because the task wording admits a plausible ambiguity.

Validation:
- a reference implementation derived from the frozen specification passed 100/100.
- the benchmark task package, created before model runs, records that the private gold passed 100/100 and a 16/16 mutation gate passed.
- the exact evaluator source hash was not delivered to the operator before the model runs. Therefore this result is strong internal evidence, but not a cryptographically precommitted blind benchmark.

No model calls are made by this evaluator.
