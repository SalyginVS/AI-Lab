# Selection and chain semantics

Records have fields:
`id, key, scope, version, state, valid_from, valid_to, value, next_key`.

The hierarchy is a tree ending at `*`. For a project, selection walks from the project to its parent(s) and finally `*`.

For each logical key and fixed `(project, at)`:
1. Inspect scopes from nearest to farthest.
2. In each scope, ignore `draft` and records outside `valid_from <= at < valid_to` (`valid_to=None` means no upper bound).
3. The first scope with any applicable candidates wins completely.
4. Within that scope, choose max `version`.
5. Multiple records with the same maximum version => `AMBIGUOUS`.
6. A selected `revoked` record => `REVOKED`; never fall back farther or to an older version.
7. No applicable record in any inspected scope => `MISSING`.

Forwarding records use `next_key` and continue with the same `(project, at)` and the same records state. Evidence is selected record ids in order.
Re-selecting an id closes a cycle: append the repeated id once more and return `CYCLE`.
A later MISSING/AMBIGUOUS preserves prior evidence.
