# VPE-Next benchmark workspace

This repository is a controlled IDE/Pi benchmark.

Run baseline checks with:

```bash
PYTHONPATH=src python3 -m unittest discover -s tests/regression -v
PYTHONPATH=src python3 -m unittest discover -s tests/public -v
```

Regression tests should be green at baseline. Public v2 acceptance contains intentionally failing cases at baseline.

Use `TASK.md` as the exact task in a fresh Pi session.
