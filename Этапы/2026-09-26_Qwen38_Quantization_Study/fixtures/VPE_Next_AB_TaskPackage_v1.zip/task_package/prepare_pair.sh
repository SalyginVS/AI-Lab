#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE="/home/vladimir/vpe_next_ab/run1"

test "$(hostname -s)" = "Precision-5560" || { echo "STOP: run on Precision-5560"; exit 1; }
test ! -e "$BASE" || { echo "STOP: $BASE already exists"; exit 1; }

mkdir -p "$BASE"
for label in q6 q5; do
  dst="$BASE/$label"
  mkdir -p "$dst"
  cp -a "$ROOT/template/." "$dst/"
  (
    cd "$dst"
    git init -q
    git config user.name "AI Lab Benchmark"
    git config user.email "benchmark@localhost"
    git add .
    git commit -qm "baseline: VPE-Next v1"
  )
done

diff -qr "$BASE/q6" "$BASE/q5" \
  --exclude=.git >/dev/null || { echo "WORKSPACE_IDENTITY=FAIL"; exit 1; }

echo "Q6_WORKSPACE=$BASE/q6"
echo "Q5_WORKSPACE=$BASE/q5"
echo "WORKSPACE_IDENTITY=PASS"
echo "PREPARE_PAIR=PASS"
