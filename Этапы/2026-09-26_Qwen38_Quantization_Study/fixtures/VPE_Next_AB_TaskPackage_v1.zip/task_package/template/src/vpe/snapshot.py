from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class Snapshot:
    _engine_token: object
    epoch: int
    records: tuple[dict[str, Any], ...]
