# Snapshot and read consistency

`record.version`, query time `at`, and engine publication `epoch` are independent.

`engine.snapshot()` returns an immutable view belonging to that engine. A snapshot keeps the records and epoch visible at creation, even after later commits.
Using another engine's snapshot raises `ValueError`.

`lookup(query, snapshot=s)` resolves only against `s`.
Snapshot reads do not use or mutate the live cache or its hit/miss counters.

`lookup_many(queries, snapshot=None)` must use one state for the entire batch:
- explicit snapshot => that snapshot for every element;
- no explicit snapshot => a snapshot of current head taken at the beginning of the call.

The engine exposes `_set_batch_hook(hook)` only as a frozen deterministic test seam. If set, the hook is invoked after each produced element with its zero-based index. A publication triggered by the hook must not change later elements of the same batch.
