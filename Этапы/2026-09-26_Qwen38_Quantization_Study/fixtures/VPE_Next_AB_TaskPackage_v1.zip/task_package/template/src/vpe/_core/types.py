from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable

Status = str
Cell = tuple[str, str]

@dataclass(frozen=True)
class Query:
    project: str
    key: str
    at: int

@dataclass(frozen=True)
class Probe:
    query: Query
    expected_value: str

@dataclass(frozen=True)
class PublishResult:
    status: str
    epoch: int
    failures: tuple[dict[str, Any], ...] = ()

@dataclass(frozen=True)
class CommitEvent:
    epoch: int
    base_epoch: int
    added_ids: tuple[str, ...]
    changed_cells: tuple[Cell, ...]
    state_digest: str

@dataclass(frozen=True)
class CacheInfo:
    entries: int
    hits: int
    misses: int

def result(status: str, value: str | None, evidence: Iterable[str]) -> dict[str, Any]:
    return {"status": status, "value": value, "evidence": list(evidence)}
