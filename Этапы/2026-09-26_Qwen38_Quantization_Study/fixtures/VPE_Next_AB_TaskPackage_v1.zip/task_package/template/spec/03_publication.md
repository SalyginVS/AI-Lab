# Transaction and publication semantics

`begin()` captures `base_epoch` and a base snapshot.

`stage(records)`:
- copies/normalizes the complete batch before adding it;
- validates against existing + already staged ids and known scopes;
- on invalid input raises the frozen validation error and changes nothing in staged state;
- leaves the transaction open.

`preview(query)` resolves against `base_snapshot + all staged records`. It never mutates head, live cache, cache counters, or audit. A stale-but-open transaction still previews its own base+staged state.

Commit outcome order is:
1. if transaction already closed => `CLOSED`;
2. if head epoch != base_epoch => `STALE`;
3. if nothing staged => `EMPTY`;
4. evaluate every probe against one full private candidate (`base + all staged`);
5. any mismatch => `VALIDATION_FAILED`;
6. otherwise publish => `PUBLISHED`.

The first call to `commit` closes the transaction for every outcome. Later `commit` returns `CLOSED`. `stage` and `preview` after close raise `RuntimeError`.

Probe success means `OK` with exact expected string. Return all failed probes in input order as `{"index": i, "result": <Result>}`.
Probes must not read, fill, evict, or alter the live cache and may not reuse prior preview results.

For `VALIDATION_FAILED`, `STALE`, or `EMPTY`, all of these remain exactly unchanged:
- head records and epoch;
- existing snapshots;
- live cache entries and hit/miss counters;
- audit log.

A successful non-empty publication atomically exposes all staged records and increments epoch by exactly one before returning.
