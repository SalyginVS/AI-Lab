# VPE-Next contract v2

Priority: this index and files 01–05 are normative. Code and tests are examples/implementation aids, not a replacement for the specification.

Requirements:
- R01 selection and hierarchy: 01_selection.md
- R02 chain resolution: 01_selection.md
- R03 version/at/epoch independence: 02_snapshot.md
- R04 snapshots: 02_snapshot.md
- R05 lookup_many single-state semantics: 02_snapshot.md
- R06 staging and preview isolation: 03_publication.md
- R07 stale transaction rejection: 03_publication.md
- R08 probes evaluate full private candidate without live cache: 03_publication.md
- R09 atomic publication / no effects on rejection: 03_publication.md
- R10 transaction lifecycle and outcome order: 03_publication.md
- R11 live-cache key and snapshot-cache isolation: 04_cache.md
- R12 dependency tracking includes inspected empty cells: 04_cache.md
- R13 selective invalidation by changed cells: 04_cache.md
- R14 cached returned values are isolated copies: 04_cache.md
- R15 deterministic audit only for successful publication: 05_audit_api.md
- R16 API result shapes/statuses: 05_audit_api.md
- R17 validation errors preserve an open transaction and previous staged data: 03_publication.md
- R18 protected core/API files remain unchanged: TASK.md

All requirements are active. There are no superseded normative files in this workspace.
