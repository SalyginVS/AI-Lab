# VPE-Next benchmark package status

Version: 1.0
Date: 2026-09-25

Pre-run validation performed before packaging:

- Baseline regression tests: 12/12 PASS.
- Baseline public v2 acceptance: intentionally RED, 12 tests total,
  with 5 failures and 1 error.
- Private gold implementation: hidden evaluator 100/100 PASS.
- Mutation gate: 16/16 deliberately injected semantic defects detected.
- Hidden evaluator is intentionally NOT included in this task package.
- First pair order is frozen: Q6_K -> Q5_K_M.
- Pi workspace-local transport settings:
  - httpIdleTimeoutMs = 0
  - retry.enabled = false

These are internal benchmark self-checks, not independent external validation.
