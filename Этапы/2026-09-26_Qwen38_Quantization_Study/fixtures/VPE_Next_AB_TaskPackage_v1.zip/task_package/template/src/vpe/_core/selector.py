from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .types import Cell
from .validation import scope_path

@dataclass(frozen=True)
class Selection:
    status: str
    record: dict[str, Any] | None
    visited_cells: tuple[Cell, ...]

def select_record(
    records: tuple[dict[str, Any], ...],
    parents: dict[str, str | None],
    project: str,
    key: str,
    at: int,
) -> Selection:
    visited: list[Cell] = []
    for scope in scope_path(parents, project):
        visited.append((key, scope))
        candidates = [
            r for r in records
            if r["key"] == key
            and r["scope"] == scope
            and r["state"] != "draft"
            and r["valid_from"] <= at
            and (r["valid_to"] is None or at < r["valid_to"])
        ]
        if not candidates:
            continue
        highest = max(r["version"] for r in candidates)
        top = [r for r in candidates if r["version"] == highest]
        if len(top) > 1:
            return Selection("AMBIGUOUS", None, tuple(visited))
        return Selection("SELECTED", top[0], tuple(visited))
    return Selection("MISSING", None, tuple(visited))
